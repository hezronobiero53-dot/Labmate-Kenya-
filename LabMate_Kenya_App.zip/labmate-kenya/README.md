# LabMate Kenya — free mobile-friendly digital product

## What it is
A responsive web app prototype for SLT students and laboratory technicians. It includes:
- Molarity calculator
- Dilution calculator
- Practical report builder
- Attachment, biology and chemistry checklists
- Lab safety basics and a quick glossary
- Search, saved resources and local progress
- Progressive Web App (PWA) install/offline support when hosted over HTTPS

## Run it locally
Open `index.html` in a modern browser. Most features work locally. Install/offline support requires serving the folder over HTTPS or localhost.

## Publish it free
1. Create a GitHub account.
2. Create a new public repository named `labmate-kenya`.
3. Upload all files in this folder (keep their names and folder structure).
4. In the repository, open **Settings → Pages**.
5. Select deploy from the `main` branch and `/ (root)`, then save.
6. After publishing, open the provided HTTPS URL on your Android phone.
7. In Chrome, use menu → **Add to Home screen** or **Install app** if offered.

Alternative: use another static-hosting service with a free tier. Provider terms and free-tier limits can change.

## How to improve and earn
- Test the calculators against worked examples and have a qualified instructor review them.
- Ask 5–10 SLT students to test the app and note confusing parts.
- Add institution-specific templates only with permission; don't use private student data.
- Potential model: keep basic tools free, and sell an optional expanded pack of printable report templates/checklists. Validate demand before charging. Do not promise income.
- A Google Play release is optional and may involve developer registration fees and extra Android packaging work.

## Important safety note
This is an educational prototype, not a validated laboratory SOP. Users must follow current institutional procedures, Safety Data Sheets, supervisor instructions and local waste/emergency rules. Do not use it as the sole authority for preparing chemicals or managing incidents.
